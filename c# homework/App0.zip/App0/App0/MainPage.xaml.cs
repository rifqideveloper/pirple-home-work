﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App0
{
    public partial class MainPage : ContentPage
    {
        String txt = "click here";
        Int32 num = 0;
        public MainPage()
        {
            Button button = new Button { 
                Text = txt
            };
            button.Clicked += btn_Clicked;
            Content = button;
            void btn_Clicked(object sender, EventArgs e)
            {
                button.Text = (num++).ToString();
            }
        }
        
    }
}
